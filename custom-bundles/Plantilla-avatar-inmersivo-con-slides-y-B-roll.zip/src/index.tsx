import React from "react";
import { AbsoluteFill, Audio, Img, Video, interpolate, useCurrentFrame, useVideoConfig } from "remotion";

type SlideAsset = {
  index?: number;
  url: string;
};

type BrollClip = {
  durationInFrames?: number;
  order?: number;
  url: string;
};

type TemplateProps = {
  accentColor?: string;
  avatarVideoUrl?: string;
  bgMusicUrl?: string;
  bgMusicVolume?: number;
  brollClips?: BrollClip[];
  slides?: SlideAsset[];
  subtitle?: string;
  title?: string;
  totalDurationInFrames?: number;
  voiceAudioUrl?: string;
};

const stylePreset = "transiciones suaves de izquierda a derecha; avatar protagonista en primera persona; layout dividido 50/50 para avatar y contenido; acentos morado elegante u oscuro; subtitulos blancos de alta legibilidad";
const defaultAccentColor = "#5B21B6";

function orderedSlides(slides: SlideAsset[] = []) {
  return slides
    .filter((slide) => typeof slide.url === "string" && slide.url.length > 0)
    .sort((left, right) => (left.index ?? 0) - (right.index ?? 0));
}

function orderedBrollClips(clips: BrollClip[] = []) {
  return clips
    .filter((clip) => typeof clip.url === "string" && clip.url.length > 0)
    .sort((left, right) => (left.order ?? 0) - (right.order ?? 0));
}

function getActiveSlide(frame: number, slides: SlideAsset[], durationInFrames: number) {
  if (slides.length === 0) return null;
  const framesPerSlide = Math.max(1, Math.floor(durationInFrames / slides.length));
  const index = Math.min(slides.length - 1, Math.floor(frame / framesPerSlide));
  return slides[index];
}

function getActiveBrollClip(frame: number, clips: BrollClip[]) {
  if (clips.length === 0) return null;
  let cursor = 0;
  for (const clip of clips) {
    const duration = Math.max(1, Math.round(clip.durationInFrames || 90));
    if (frame >= cursor && frame < cursor + duration) {
      return clip;
    }
    cursor += duration;
  }
  return clips[clips.length - 1];
}

export default function SofliaGeneratedTemplate(props: TemplateProps) {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const progress = interpolate(frame, [0, Math.max(1, durationInFrames - 1)], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const title = props.title || "Plantilla avatar inmersivo con slides y B-roll";
  const subtitle = props.subtitle || "Plantilla avatar inmersivo con slides y B-roll: Crea una nueva versión del bundle Remotion corrigiendo la plantilla anterior. Objetivo: La plantilla debe consumir assets reales del pipeline de Courseforge, no mostrar solo placeholders. Debe usar estos props cuando existan: avatarVideoUrl para mostrar el avatar en video. voiceAudioUrl para reproducir la locución principal. slides para mostrar diapositivas en orden. brollClips para mostrar B-roll cuando no haya slide activa. bgMusicUrl y bgMusicVolume para música de fondo. title, subtitle y accentColor como textos/configuración visual. Diseño: Layout 50/50. Avatar a la izquierda, ocupando media pantalla. Slides o B-roll a la derecha. Transiciones suaves de izquierda a derecha. Acentos morado elegante/oscuro. Subtítulos en blanco con alto contraste. Si falta un asset, mostrar fallback visual elegante, pero nunca ignorar assets cuando existan. Importante: Genera una versión compatible con el contrato canónico de Courseforge y Remotion Lamb";
  const accentColor = props.accentColor || defaultAccentColor;
  const slides = orderedSlides(props.slides);
  const brollClips = orderedBrollClips(props.brollClips);
  const activeSlide = getActiveSlide(frame, slides, durationInFrames);
  const activeBroll = slides.length > 0 ? null : getActiveBrollClip(frame, brollClips);
  const hasAvatar = typeof props.avatarVideoUrl === "string" && props.avatarVideoUrl.length > 0;
  const hasVoice = typeof props.voiceAudioUrl === "string" && props.voiceAudioUrl.length > 0;
  const hasSupportVisual = Boolean(activeSlide || activeBroll);
  const panelIn = interpolate(frame, [0, 36], [-80, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const contentIn = interpolate(frame, [18, 54], [140, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill
      style={{
        background: "linear-gradient(135deg, #09090f 0%, #151022 48%, #2e1065 100%)",
        color: "white",
        fontFamily: "Inter, Arial, sans-serif",
        padding: 72,
      }}
    >
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 44,
          height: "100%",
          alignItems: "stretch",
        }}
      >
        <section
          style={{
            border: `2px solid ${accentColor}`,
            borderRadius: 28,
            background: "linear-gradient(180deg, rgba(91,33,182,0.26), rgba(12,10,18,0.9))",
            boxShadow: `0 28px 80px rgba(0,0,0,0.34), inset 0 0 48px ${accentColor}44`,
            padding: 48,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            transform: `translateX(${panelIn}px)`,
            opacity: interpolate(frame, [0, 24], [0, 1], { extrapolateRight: "clamp" }),
          }}
        >
          <div
            style={{
              display: "inline-flex",
              alignSelf: "flex-start",
              border: "1px solid rgba(255,255,255,0.24)",
              borderRadius: 999,
              padding: "10px 18px",
              fontSize: 24,
              background: "rgba(255,255,255,0.08)",
            }}
          >
            {hasAvatar ? "Avatar en primera persona" : "Avatar pendiente"}
          </div>
          {hasAvatar ? (
            <div style={{ flex: 1, minHeight: 0, borderRadius: 28, overflow: "hidden", background: "rgba(0,0,0,0.24)" }}>
              <Video
                src={props.avatarVideoUrl!}
                muted={hasVoice}
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
            </div>
          ) : (
            <div
              style={{
                height: 520,
                borderRadius: 260,
                background: `radial-gradient(circle at 50% 32%, rgba(255,255,255,0.28), ${accentColor} 38%, rgba(12,10,18,0.2) 68%)`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 42,
                fontWeight: 800,
                textAlign: "center",
              }}
            >
              POV
            </div>
          )}
          <p style={{ fontSize: 28, lineHeight: 1.35, color: "rgba(255,255,255,0.82)", margin: 0 }}>
            {hasVoice ? "Locucion principal activa." : "Sin locucion principal adjunta."}
          </p>
        </section>

        <section
          style={{
            borderRadius: 28,
            background: "rgba(255,255,255,0.08)",
            border: "1px solid rgba(255,255,255,0.18)",
            padding: 56,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            transform: `translateX(${contentIn}px)`,
            opacity: interpolate(frame, [18, 54], [0, 1], { extrapolateRight: "clamp" }),
          }}
        >
          <div style={{ width: 120, height: 8, borderRadius: 999, background: accentColor, marginBottom: 36 }} />
          {activeSlide ? (
            <Img src={activeSlide.url} style={{ width: "100%", height: "58%", objectFit: "contain", borderRadius: 20, background: "rgba(0,0,0,0.24)" }} />
          ) : activeBroll ? (
            <Video src={activeBroll.url} muted style={{ width: "100%", height: "58%", objectFit: "cover", borderRadius: 20, background: "rgba(0,0,0,0.24)" }} />
          ) : (
            <>
              <h1 style={{ fontSize: 78, lineHeight: 1.02, margin: 0, letterSpacing: 0 }}>{title}</h1>
              <p style={{ fontSize: 34, lineHeight: 1.28, marginTop: 30, color: "rgba(255,255,255,0.9)" }}>{subtitle}</p>
              <p style={{ fontSize: 22, lineHeight: 1.42, marginTop: 28, color: "rgba(255,255,255,0.68)" }}>
                Direccion visual: {stylePreset}
              </p>
            </>
          )}
          {hasSupportVisual ? (
            <div style={{ marginTop: 26, borderRadius: 18, background: "rgba(0,0,0,0.38)", padding: "18px 22px", fontSize: 26, lineHeight: 1.28, color: "white" }}>
              {subtitle}
            </div>
          ) : null}
          <div
            style={{
              height: 8,
              width: "100%",
              background: "rgba(255,255,255,0.18)",
              borderRadius: 999,
              overflow: "hidden",
              marginTop: 44,
            }}
          >
            <div
              style={{
                height: "100%",
                width: `${Math.round(progress * 100)}%`,
                background: accentColor,
              }}
            />
          </div>
        </section>
      </div>
      {hasVoice ? <Audio src={props.voiceAudioUrl!} /> : null}
      {props.bgMusicUrl ? <Audio src={props.bgMusicUrl} volume={props.bgMusicVolume ?? 0.15} /> : null}
    </AbsoluteFill>
  );
}
