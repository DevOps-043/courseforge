# Remotion advanced example

Bundle de ejemplo para validar plantillas externas de Courseforge.

Incluye:

- Manifest requerido por Courseforge.
- Composicion React/Remotion autocontenida.
- Subtitulos temporizados.
- Cambios de posicion de avatar por escena.
- Placeholder visual para B-roll y progreso narrativo.

Este ZIP esta pensado para validacion estatica y revision humana. En la V1 de
bundles externos Courseforge no ejecuta codigo del ZIP.
