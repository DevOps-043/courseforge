import React from 'react';
import {Composition, registerRoot, type CalculateMetadataFunction} from 'remotion';
import {AssembledVideo} from './compositions/AssembledVideo';
import {getManifestDuration} from './lib/timing';
import type {RenderProps, VideoAssemblyManifest} from './types';

const fallbackManifest: VideoAssemblyManifest = {
  project: {id: 'courseforge-template-base', title: 'Video ensamblado', format: '16:9', width: 1920, height: 1080, fps: 30, language: 'es-MX', style: 'corporate-explainer', accentColor: '#00D4B3'},
  assets: [],
  scenes: [{id: 'scene-01', type: 'title-card', durationSec: 5, label: 'Plantilla Remotion', title: 'Añade escenas en tu manifiesto', subtitle: 'La composición calcula la línea de tiempo automáticamente.'}],
  audio: {musicVolume: 0.12},
};

const defaultProps: RenderProps = fallbackManifest;

export const calculateMetadata: CalculateMetadataFunction<RenderProps> = ({props}) => {
  const manifest = props.project ? props : fallbackManifest;
  return {durationInFrames: Math.max(1, getManifestDuration(manifest)), fps: manifest.project.fps, width: manifest.project.width, height: manifest.project.height};
};

export const RemotionRoot = () => (
  <Composition id="courseforge-template-base" component={AssembledVideo} durationInFrames={150} fps={30} width={1920} height={1080} defaultProps={defaultProps} calculateMetadata={calculateMetadata} />
);

registerRoot(RemotionRoot);
