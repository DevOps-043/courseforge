import {staticFile} from 'remotion';
import type {VideoAssemblyManifest} from '../types';

export const findAsset = (manifest: VideoAssemblyManifest, id: string) => {
  const asset = manifest.assets.find((item) => item.id === id);
  if (!asset) throw new Error(`Asset not found in manifest: ${id}`);
  return asset;
};

export const assetSrc = (manifest: VideoAssemblyManifest, id?: string) =>
  id ? staticFile(findAsset(manifest, id).path) : undefined;
