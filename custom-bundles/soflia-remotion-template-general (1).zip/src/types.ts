import type {CSSProperties} from 'react';

export type AssetType = 'image' | 'video' | 'audio' | 'caption' | 'json' | 'svg' | 'font' | 'html';

export type AssemblyAsset = {
  id: string;
  type: AssetType;
  path: string;
  description?: string;
  durationSec?: number;
  role?: 'avatar' | 'slide' | 'broll' | 'voiceover' | 'music' | 'brand' | 'caption' | 'other';
  metadata?: {
    mimeType?: string;
    codec?: string;
    fileSizeBytes?: number;
    checksumSha256?: string;
    width?: number;
    height?: number;
    fps?: number;
    hasAudio?: boolean;
    aspectRatio?: number;
    subjectAnchor?: {x: number; y: number};
    safeArea?: {top?: number; right?: number; bottom?: number; left?: number};
    preferredFit?: 'contain' | 'cover' | 'stretch';
    loop?: boolean;
    alpha?: boolean;
    contentBounds?: {x: number; y: number; width: number; height: number};
    renderer?: 'raster' | 'html' | 'component';
    textEmbedded?: boolean;
    sampleRateHz?: number;
    channels?: number;
    loudnessLufs?: number;
    language?: string;
    speaker?: string;
    bpm?: number;
    captionFormat?: 'srt' | 'vtt' | 'json';
    license?: string;
  };
};

export type SceneType = 'title-card' | 'image-focus' | 'video-clip' | 'quote' | 'stat-highlight' | 'process-step' | 'comparison' | 'screen-demo' | 'recap' | 'cta';

export type MotionSpec = {
  entrance?: 'soft-fade' | 'soft-scale-fade' | 'slide-up' | 'slide-left' | 'mask-reveal';
  transitionOut?: 'crossfade' | 'panel-wipe' | 'none';
  emphasis?: string[];
};

export type SceneLayoutMode = 'full-avatar' | 'centered-slide' | 'split-avatar-slide' | 'slide-broll' | 'centered-brand' | 'custom';

export type VisualSlot = {
  assetRef?: string;
  sourceStartSec?: number;
  sourceEndSec?: number;
  x: number;
  y: number;
  width: number;
  height: number;
  fit?: 'contain' | 'cover' | 'stretch';
  objectPosition?: string;
  opacity?: number;
  borderRadius?: number;
  zIndex?: number;
  safeTextBox?: {x: number; y: number; width: number; height: number};
};

export type SceneLayout = {
  mode: SceneLayoutMode;
  slots?: Record<string, VisualSlot>;
  background?: string;
};

export type LayerSpec = {
  id: string;
  kind: 'avatar' | 'slide' | 'broll' | 'caption' | 'brand' | 'custom';
  assetRef?: string;
  componentId?: string;
  visible?: boolean;
  zIndex: number;
  timeMode?: 'timeline' | 'trim';
  sourceStartSec?: number;
  sourceEndSec?: number;
  box: LayoutBox;
  fit?: 'contain' | 'cover' | 'stretch';
  objectPosition?: string;
  opacity?: number;
  borderRadius?: number;
  safeTextBox?: {x: number; y: number; width: number; height: number};
};

export type TimelineClip = {
  id: string;
  assetRef?: string;
  componentId?: string;
  fromSec: number;
  toSec: number;
  sourceStartSec?: number;
  sourceEndSec?: number;
  box: LayoutBox;
  fit?: 'contain' | 'cover' | 'stretch';
  objectPosition?: string;
  opacity?: number;
  borderRadius?: number;
  muted?: boolean;
  volume?: number;
  loop?: boolean;
  safeTextBox?: {x: number; y: number; width: number; height: number};
};

export type TimelineTrack = {
  id: string;
  kind: 'avatar' | 'slide' | 'broll' | 'caption' | 'audio' | 'brand' | 'custom';
  zIndex: number;
  clips: TimelineClip[];
};

export type AssemblyTimeline = {
  tracks: TimelineTrack[];
};

export type AssemblyScene = {
  id: string;
  type: SceneType;
  durationSec: number;
  title?: string;
  subtitle?: string;
  body?: string;
  label?: string;
  value?: string;
  assetRefs?: string[];
  motion?: MotionSpec;
  background?: string;
  layout?: SceneLayout;
  baseLayerVisible?: boolean;
  layers?: LayerSpec[];
  data?: Record<string, unknown>;
};

export type AudioConfig = {
  voiceoverRef?: string | null;
  musicRef?: string | null;
  musicVolume?: number;
  ducking?: boolean;
};

export type CaptionConfig = {
  enabled?: boolean;
  source?: 'inline-or-srt' | 'asset';
  assetRef?: string;
  style?: 'bottom-safe-area' | 'boxed';
};

export type VideoAssemblyManifest = {
  project: {
    id: string;
    title?: string;
    format: string;
    width: number;
    height: number;
    fps: number;
    language?: string;
    style?: string;
    accentColor?: string;
    durationSec?: number;
  };
  assets: AssemblyAsset[];
  baseLayer?: LayerSpec;
  timeline?: AssemblyTimeline;
  scenes?: AssemblyScene[];
  audio?: AudioConfig;
  captions?: CaptionConfig;
};

export type TimedScene = AssemblyScene & {from: number; durationInFrames: number};

export type LayoutBox = {x: number; y: number; width: number; height: number};

export type LayoutOverrideEdit =
  | {layerId: string; kind: 'position'; x: number; y: number}
  | {layerId: string; kind: 'size'; width: number; height: number}
  | {layerId: string; kind: 'visibility'; hidden: boolean};

export type LayoutOverrideManifest = {version?: number; edits?: LayoutOverrideEdit[]};

export type LegacyTemplateProps = {
  manifest?: VideoAssemblyManifest;
  accentColor?: string;
  avatarVideoUrl?: string;
  bgMusicUrl?: string;
  bgMusicVolume?: number;
  brollClips?: {durationInFrames?: number; order?: number; url: string}[];
  layoutOverrides?: LayoutOverrideManifest[];
  slides?: {index?: number; url: string}[];
  totalDurationInFrames?: number;
  voiceAudioUrl?: string;
};

export type RenderProps = VideoAssemblyManifest;

export const boxStyle = (box: LayoutBox, overrides: CSSProperties = {}): CSSProperties => ({
  position: 'absolute', left: box.x, top: box.y, width: box.width, height: box.height,
  overflow: 'hidden', ...overrides,
});
