# SofLIA Engine — plantilla de ensamblaje Remotion

Plantilla base para convertir un `video-assembly-manifest.json` y sus medios en un video renderizable con Remotion. La plantilla separa la generación de assets del ensamblaje: el upstream produce el manifiesto y `public/assets`, y Remotion calcula la línea de tiempo y renderiza las escenas.

## Estructura

```text
public/assets/video-assembly-manifest.json  # entrada de ejemplo
src/types.ts                                # contrato tipado
src/lib/timing.ts                           # segundos → frames y timeline
src/lib/assets.ts                            # resolución de assets locales
src/components/SceneRenderer.tsx             # layouts por tipo de escena
src/compositions/AssembledVideo.tsx           # composición y audio
src/index.tsx                                # registro de Remotion
```

## Contrato de entrada

El manifiesto contiene:

- `project`: formato, dimensiones, FPS, idioma y color de marca.
- `assets`: `{ id, type, path }`; los archivos deben vivir en `public/`.
- `timeline.tracks`: clips independientes con `fromSec`, `toSec`, posición y orden de capa.
- `scenes`: modo anterior compatible; se usa sólo si no existe `timeline`.
- `audio`: referencias por `id` para voz y música.
- `captions`: configuración reservada para la capa de subtítulos.

La duración se toma de `project.durationSec` o, si se omite, del mayor `toSec` del timeline. En el modo anterior se deriva de la suma de `scenes[].durationSec`.

La plantilla es fija; cada video aporta un JSON distinto. El contrato de referencia está en [examples/video-project.timeline.json](examples/video-project.timeline.json).

## Perfil de video incorporado

El plan de escenas soporta los bloques observados: avatar a pantalla completa, slides centrados, split 50/50 avatar-slide, slide con B-roll a la izquierda y cierres de marca. Cada slot usa coordenadas en píxeles sobre el canvas de 1920×1080 y puede declarar `fit`, `objectPosition` y `safeTextBox`.

Las posiciones que no estaban explícitas en la radiografía —por ejemplo, el `x/y` exacto de algunas cajas centradas— son inferencias geométricas y deben confirmarse con un frame de referencia.

## Modelo por capas

`manifest.baseLayer` representa el avatar largo como track base continuo. Cada escena puede agregar `layers` encima, ordenadas por `zIndex`. Por ejemplo, un segmento con avatar + slide + B-roll se expresa como tres capas: base avatar en `zIndex: 0`, slide en `zIndex: 10` y B-roll en `zIndex: 20`. Un segmento sólo con slide puede usar `baseLayerVisible: false`.

El campo `timeMode: "timeline"` hace que el avatar avance con el tiempo global del video. Para un overlay recortado se usa `timeMode: "trim"` junto con `sourceStartSec` y `sourceEndSec`.

Una slide puede ser `image`/`svg` para PNGs o `html` para un archivo HTML local autocontenido. Si el contenido necesita React/TypeScript, la extensión recomendada es registrar un `componentId` y convertir ese componente en una capa renderizable dentro de `SceneRenderer`.

## Uso

```bash
npm install
npm run studio
npm run render
```

Para renderizar un proyecto externo:

```bash
npx remotion render src/index.tsx courseforge-template-base out/mi-video.mp4 \
  --props=/ruta/al/video-project.json
```

El JSON se pasa directamente como props de la composición; no debe envolverse dentro de otra propiedad `manifest`.

Para una variante, copia el manifiesto, agrega los archivos a `public/assets` y cambia `assetRefs` o las referencias de audio. Los tipos de escena disponibles están declarados en `src/types.ts`; el punto de extensión visual es `src/components/SceneRenderer.tsx`.

La base original (`avatar`, `slides`, `b-roll` y `layoutOverrides`) se conserva en el archivo de contrato `courseforge-remotion-template.json` para que el editor existente pueda seguir identificando esas capas. La nueva composición usa el manifiesto explícito como camino principal.

Consulta el [contrato de metadatos de assets](docs/asset-metadata.md) antes de conectar el catálogo real.

Para preparar un proyecto nuevo, sigue [la estructura de proyecto](docs/project-structure.md), parte de `projects/video-project.template.json` y consulta `examples/asset-metadata.examples.json`.

Valida y renderiza un proyecto con:

```bash
npm run validate -- projects/mi-video.json
npm run render:project -- --props=projects/mi-video.json
```
