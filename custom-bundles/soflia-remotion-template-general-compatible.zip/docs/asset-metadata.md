# Metadatos requeridos por asset

Cada asset debe tener como mínimo:

```json
{
  "id": "avatar-main",
  "type": "video",
  "path": "assets/avatar-main.mp4",
  "role": "avatar",
  "durationSec": 169.6,
  "metadata": {
    "width": 1920,
    "height": 1080,
    "fps": 30,
    "hasAudio": true,
    "aspectRatio": 1.7778,
    "preferredFit": "cover",
    "subjectAnchor": {"x": 0.42, "y": 0.32},
    "loop": false,
    "alpha": false
  }
}
```

## Campos comunes

- `id`: identificador único y estable; las escenas lo usan en `assetRef`.
- `type`: `image`, `video`, `audio`, `caption`, `json`, `svg` o `font`.
- `path`: ruta relativa dentro de `public/`.
- `role`: `avatar`, `slide`, `broll`, `voiceover`, `music`, `brand`, `caption` u `other`.
- `description`: propósito humano del archivo.
- `durationSec`: obligatorio para video/audio; útil para validar segmentos.

## Metadatos visuales

- `width`, `height`, `fps`: dimensiones y cadencia reales del archivo.
- `aspectRatio`: `width / height`, para decidir si el asset puede ir en una caja sin deformarse.
- `preferredFit`: `contain` para slides, `cover` para avatar/B-roll y `stretch` solo si está autorizado.
- `subjectAnchor`: coordenada normalizada del sujeto principal, especialmente necesaria para avatar (`{x: 0.42, y: 0.32}` significa 42% desde la izquierda y 32% desde arriba).
- `safeArea`: márgenes normalizados donde no deben caer subtítulos, logos o UI.
- `contentBounds`: caja normalizada del contenido útil dentro de una slide exportada con márgenes.
- `alpha`: indica transparencia; importante para logos, overlays y elementos de marca.
- `loop`: permite repetir B-roll corto sin inventar una nueva escena.

## Metadatos temporales

Para un asset que aparece por segmentos, se necesita además un registro de uso —en la escena o en un archivo de edición— con:

```json
{
  "assetRef": "avatar-main",
  "sourceStartSec": 7.9,
  "sourceEndSec": 21.6,
  "trimMode": "source-time"
}
```

La plantilla usa `scene.durationSec` para el timeline final. `sourceStartSec` y `sourceEndSec` indican qué tramo del archivo fuente debe reproducirse.

## Capas

La composición se organiza como un track base y overlays:

```json
{
  "baseLayer": {
    "id": "base-avatar-track",
    "kind": "avatar",
    "assetRef": "avatar-main",
    "zIndex": 0,
    "timeMode": "timeline",
    "box": {"x": 0, "y": 0, "width": 1920, "height": 1080}
  },
  "layers": [
    {
      "id": "slide-layer",
      "kind": "slide",
      "assetRef": "slide-03",
      "zIndex": 10,
      "timeMode": "trim",
      "box": {"x": 1191, "y": 298, "width": 729, "height": 484},
      "fit": "contain"
    },
    {
      "id": "broll-layer",
      "kind": "broll",
      "assetRef": "broll-03",
      "zIndex": 20,
      "box": {"x": 0, "y": 60, "width": 842, "height": 960},
      "fit": "cover"
    }
  ]
}
```

`zIndex` es la regla de apilado. La capa base no se duplica: se conserva durante toda la escena y sólo se oculta cuando `baseLayerVisible` es `false`.

## Por tipo de asset

- Avatar: `width`, `height`, `fps`, `durationSec`, `subjectAnchor`, `hasAudio`, `preferredFit` y, si hay cambios de encuadre, `subjectAnchor` por segmento.
- Slide: dimensiones, `contentBounds`, `preferredFit: contain`, fondo/transparencia y si el texto ya está rasterizado o debe renderizarse como datos editables.
- B-roll: dimensiones, duración, FPS, `preferredFit`, `loop`, punto focal opcional y si contiene audio utilizable.
- Voz: duración, sample rate, canales, idioma, speaker y nivel normalizado.
- Música: duración, BPM opcional, loop permitido, nivel objetivo y si admite ducking bajo la voz.
- Caption/SRT/VTT: idioma, intervalo temporal, fuente de transcripción y estilo solicitado.
- Brand/logo/font: variante, color, formato, transparencia, licencia y familia/peso tipográfico.

## Datos que aún faltan para cerrar la plantilla

1. Mapeo de archivos reales a los 15 bloques: avatar, slides 1–9 y B-roll de slides 3 y 5.
2. Si el avatar es un único video o varios clips, y los offsets exactos dentro del archivo fuente.
3. FPS/resolución definitivos y timecodes exactos por frame; la tabla se marcó como aproximada.
4. Coordenadas `x/y` exactas de cada caja y posición focal del rostro por segmento.
5. Qué slide corresponde a cada asset y si sus textos son imagen plana o capas editables.
6. Voz, música, volumen objetivo, ducking, captions y reglas de transición entre escenas.
7. Kit de marca: fuentes, logo, colores, fondos y safe areas obligatorias.
