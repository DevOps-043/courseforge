# Estructura para completar un video

Duplica `projects/video-project.template.json` por cada video y conserva los medios dentro de `public/assets`.

```text
soflia-remotion-template/
├── projects/
│   ├── video-project.template.json
│   ├── curso-001.json
│   └── curso-002.json
├── public/
│   └── assets/
│       ├── avatar/
│       │   └── avatar-main.mp4
│       ├── slides/
│       │   ├── slide-01.png
│       │   └── slide-02/
│       │       ├── index.html
│       │       ├── styles.css
│       │       └── media/
│       ├── broll/
│       │   └── broll-01.mp4
│       ├── audio/
│       │   ├── voice-main.wav
│       │   └── music-main.mp3
│       ├── captions/
│       │   └── captions-es.vtt
│       └── brand/
│           └── logo.svg
├── schemas/video-project.schema.json
├── scripts/validate-manifest.js
└── src/
```

## Flujo por video

1. Copia `projects/video-project.template.json` y asigna un `project.id` único.
2. Coloca cada medio en la carpeta correspondiente de `public/assets`.
3. Registra cada archivo una sola vez dentro de `assets[]`, con `id`, `type`, `path`, `role` y `metadata`.
4. En `timeline.tracks[].clips[]`, usa `assetRef` para indicar cuándo y dónde aparece.
5. Valida el proyecto con `npm run validate -- projects/curso-001.json`.
6. Renderiza con `npm run render:project -- --props=projects/curso-001.json`.

## Relación entre asset y clip

El asset describe el archivo; el clip describe un uso del archivo.

```json
{
  "assets": [
    {
      "id": "slide-01",
      "type": "image",
      "path": "assets/slides/slide-01.png",
      "role": "slide",
      "metadata": {
        "width": 1920,
        "height": 1080,
        "aspectRatio": 1.7778,
        "preferredFit": "contain",
        "renderer": "raster",
        "textEmbedded": true
      }
    }
  ],
  "timeline": {
    "tracks": [
      {
        "id": "slides-track",
        "kind": "slide",
        "zIndex": 10,
        "clips": [
          {
            "id": "slide-01-use-01",
            "assetRef": "slide-01",
            "fromSec": 5,
            "toSec": 12,
            "box": {"x": 964, "y": 0, "width": 956, "height": 1080},
            "fit": "contain"
          }
        ]
      }
    ]
  }
}
```

El mismo `assetRef` puede aparecer en varios clips con tiempos, cajas y recortes distintos.
