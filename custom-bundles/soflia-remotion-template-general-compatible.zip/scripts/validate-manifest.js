const {readFileSync} = require('node:fs');
const {resolve} = require('node:path');

const manifestPath = resolve(process.argv[2] ?? 'projects/video-project.template.json');
const errors = [];
const warnings = [];
let manifest;

try {
  manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
} catch (error) {
  console.error(`No se pudo leer ${manifestPath}: ${error.message}`);
  process.exit(1);
}

const project = manifest.project ?? {};
if (!project.id) errors.push('project.id es obligatorio.');
if (!(project.width > 0) || !(project.height > 0)) errors.push('project.width y project.height deben ser positivos.');
if (!(project.fps > 0)) errors.push('project.fps debe ser positivo.');

const assets = Array.isArray(manifest.assets) ? manifest.assets : [];
const assetIds = new Set();
for (const asset of assets) {
  if (!asset.id) errors.push('Todos los assets necesitan id.');
  if (assetIds.has(asset.id)) errors.push(`Asset duplicado: ${asset.id}`);
  assetIds.add(asset.id);
  if (!asset.type || !asset.path || !asset.role) errors.push(`Asset ${asset.id ?? '<sin-id>'}: type, path y role son obligatorios.`);
  if (!asset.metadata) errors.push(`Asset ${asset.id ?? '<sin-id>'}: metadata es obligatorio.`);
  if (['image', 'video', 'svg', 'html'].includes(asset.type) && (!(asset.metadata?.width > 0) || !(asset.metadata?.height > 0))) errors.push(`Asset ${asset.id}: width y height son obligatorios para medios visuales.`);
  if (asset.type === 'video' && (!(asset.durationSec > 0) || !(asset.metadata?.fps > 0))) errors.push(`Asset ${asset.id}: durationSec y metadata.fps son obligatorios para video.`);
  if (asset.type === 'audio' && !(asset.durationSec > 0)) errors.push(`Asset ${asset.id}: durationSec es obligatorio para audio.`);
}

const tracks = manifest.timeline?.tracks;
if (!Array.isArray(tracks)) errors.push('timeline.tracks debe ser un arreglo.');
for (const track of tracks ?? []) {
  if (!track.id || !track.kind || !Number.isFinite(track.zIndex)) errors.push('Cada track necesita id, kind y zIndex.');
  if (!Array.isArray(track.clips)) errors.push(`Track ${track.id ?? '<sin-id>'}: clips debe ser un arreglo.`);
  for (const clip of track.clips ?? []) {
    const label = `${track.id}/${clip.id ?? '<sin-id>'}`;
    if (!clip.id) errors.push(`Clip sin id en track ${track.id}.`);
    if (!(clip.fromSec >= 0) || !(clip.toSec > clip.fromSec)) errors.push(`Clip ${label}: toSec debe ser mayor que fromSec.`);
    if (clip.assetRef && !assetIds.has(clip.assetRef)) errors.push(`Clip ${label}: assetRef inexistente (${clip.assetRef}).`);
    if (!clip.assetRef && !clip.componentId) errors.push(`Clip ${label}: necesita assetRef o componentId.`);
    if (!(clip.box?.width > 0) || !(clip.box?.height > 0)) errors.push(`Clip ${label}: box.width y box.height deben ser positivos.`);
    if (project.durationSec && clip.toSec > project.durationSec) errors.push(`Clip ${label}: termina después de project.durationSec.`);
    if (clip.box && (clip.box.x < 0 || clip.box.y < 0 || clip.box.x + clip.box.width > project.width || clip.box.y + clip.box.height > project.height)) warnings.push(`Clip ${label}: su caja sale del canvas; puede ser intencional para crop.`);
    if (clip.sourceStartSec !== undefined && clip.sourceEndSec !== undefined && clip.sourceEndSec <= clip.sourceStartSec) errors.push(`Clip ${label}: sourceEndSec debe ser mayor que sourceStartSec.`);
  }
}

for (const warning of warnings) console.warn(`ADVERTENCIA: ${warning}`);
if (errors.length) {
  for (const error of errors) console.error(`ERROR: ${error}`);
  console.error(`\nManifiesto inválido: ${errors.length} error(es).`);
  process.exit(1);
}

console.log(`Manifiesto válido: ${manifestPath}`);
console.log(`${assets.length} asset(s), ${(tracks ?? []).length} track(s).`);
