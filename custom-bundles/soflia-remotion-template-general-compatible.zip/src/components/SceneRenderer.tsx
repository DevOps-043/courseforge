import React from 'react';
import {AbsoluteFill, Img, OffthreadVideo, interpolate, useCurrentFrame} from 'remotion';
import {assetSrc} from '../lib/assets';
import type {LayerSpec, TimedScene, VideoAssemblyManifest, VisualSlot} from '../types';

const enterStyle = (scene: TimedScene, frame: number): React.CSSProperties => {
  const progress = interpolate(frame, [0, 14], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const entrance = scene.motion?.entrance ?? 'soft-scale-fade';
  if (entrance === 'slide-up') return {opacity: progress, transform: `translateY(${(1 - progress) * 28}px)`};
  if (entrance === 'slide-left') return {opacity: progress, transform: `translateX(${(1 - progress) * 28}px)`};
  if (entrance === 'soft-fade') return {opacity: progress};
  return {opacity: progress, transform: `scale(${0.96 + progress * 0.04})`};
};

const normalizeObjectFit = (
  fit: LayerSpec['fit'] | VisualSlot['fit'] | undefined,
  fallback: LayerSpec['fit'] | VisualSlot['fit'] | undefined,
): React.CSSProperties['objectFit'] => {
  const value = fit ?? fallback ?? 'cover';
  return value === 'stretch' ? 'fill' : value;
};

export const SceneRenderer: React.FC<{scene: TimedScene; manifest: VideoAssemblyManifest}> = ({scene, manifest}) => {
  const frame = useCurrentFrame();
  const firstAsset = scene.assetRefs?.[0];
  const asset = firstAsset ? manifest.assets.find((item) => item.id === firstAsset) : undefined;
  const style = enterStyle(scene, frame);
  const accent = manifest.project.accentColor ?? '#00D4B3';
  const renderLayer = (layer: LayerSpec) => {
    if (layer.visible === false) return null;
    const layerAsset = layer.assetRef ? manifest.assets.find((item) => item.id === layer.assetRef) : undefined;
    if (!layerAsset) return null;
    const src = assetSrc(manifest, layerAsset.id);
    const timeStart = layer.timeMode === 'timeline'
      ? scene.from / manifest.project.fps
      : layer.sourceStartSec;
    const common = {position: 'absolute' as const, left: layer.box.x, top: layer.box.y, width: layer.box.width, height: layer.box.height, objectFit: normalizeObjectFit(layer.fit, layerAsset.metadata?.preferredFit), objectPosition: layer.objectPosition ?? 'center center', opacity: layer.opacity ?? 1, zIndex: layer.zIndex, borderRadius: layer.borderRadius ?? 0};
    if (layerAsset.type === 'image' || layerAsset.type === 'svg') return <Img key={layer.id} src={src!} style={common} />;
    if (layerAsset.type === 'html') return <iframe key={layer.id} title={layer.id} src={src!} style={{...common, border: 0}} />;
    if (layerAsset.type === 'video') return <OffthreadVideo key={layer.id} src={src!} muted={layer.kind !== 'avatar'} startFrom={timeStart !== undefined ? Math.round(timeStart * manifest.project.fps) : undefined} endAt={layer.sourceEndSec !== undefined ? Math.round(layer.sourceEndSec * manifest.project.fps) : undefined} style={common} />;
    return null;
  };
  const layerStack = [
    ...(manifest.baseLayer && scene.baseLayerVisible !== false ? [{...manifest.baseLayer, timeMode: 'timeline' as const}] : []),
    ...(scene.layers ?? []),
  ].sort((left, right) => left.zIndex - right.zIndex);
  const slots = scene.layout?.slots ?? {};
  const renderSlot = (name: string, fallbackAssetId?: string) => {
    const slot: VisualSlot | undefined = slots[name];
    const assetId = slot?.assetRef ?? fallbackAssetId;
    const slotAsset = assetId ? manifest.assets.find((item) => item.id === assetId) : undefined;
    if (!slot || !slotAsset) return null;
    const src = assetSrc(manifest, slotAsset.id);
    const common = {position: 'absolute' as const, left: slot.x, top: slot.y, width: slot.width, height: slot.height, objectFit: normalizeObjectFit(slot.fit, slotAsset.metadata?.preferredFit), objectPosition: slot.objectPosition ?? 'center center', opacity: slot.opacity ?? 1, zIndex: slot.zIndex ?? 2, borderRadius: slot.borderRadius ?? 0};
    if (slotAsset.type === 'image' || slotAsset.type === 'svg') return <Img key={name} src={src!} style={common} />;
    if (slotAsset.type === 'video') return <OffthreadVideo key={name} src={src!} muted={slotAsset.role === 'broll' || slotAsset.role === 'avatar'} startFrom={slot.sourceStartSec ? Math.round(slot.sourceStartSec * manifest.project.fps) : undefined} endAt={slot.sourceEndSec ? Math.round(slot.sourceEndSec * manifest.project.fps) : undefined} style={common} />;
    return null;
  };

  return (
    <AbsoluteFill style={{background: scene.layout?.background ?? scene.background ?? '#090d14', color: '#f7fbff', padding: 72}}>
      <div style={{position: 'absolute', inset: 0, background: `radial-gradient(circle at 75% 20%, ${accent}22, transparent 42%)`}} />
      {layerStack.map(renderLayer)}
      {renderSlot('background')}
      {renderSlot('broll')}
      {renderSlot('slide', firstAsset)}
      {renderSlot('avatar')}
      <div style={{position: 'relative', zIndex: 1, height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', ...style}}>
        {scene.label ? <div style={{color: accent, fontSize: 24, fontWeight: 700, letterSpacing: 2, textTransform: 'uppercase'}}>{scene.label}</div> : null}
        {scene.title ? <h1 style={{fontSize: 76, lineHeight: 1.03, margin: '18px 0 14px', maxWidth: 1200}}>{scene.title}</h1> : null}
        {scene.subtitle ? <p style={{fontSize: 34, color: '#b8c4d3', maxWidth: 980, margin: 0}}>{scene.subtitle}</p> : null}
        {scene.body ? <p style={{fontSize: 26, lineHeight: 1.4, color: '#d8e1eb', maxWidth: 900}}>{scene.body}</p> : null}
        {scene.value ? <div style={{fontSize: 120, fontWeight: 800, color: accent, marginTop: 22}}>{scene.value}</div> : null}
        {asset?.type === 'image' || asset?.type === 'svg' ? <Img src={assetSrc(manifest, asset.id)!} style={{position: 'absolute', right: 0, bottom: 0, width: '48%', maxHeight: '78%', objectFit: 'contain'}} /> : null}
        {asset?.type === 'video' ? <OffthreadVideo src={assetSrc(manifest, asset.id)!} muted style={{position: 'absolute', right: 0, bottom: 0, width: '48%', height: '64%', objectFit: 'cover', borderRadius: 24}} /> : null}
      </div>
    </AbsoluteFill>
  );
};
