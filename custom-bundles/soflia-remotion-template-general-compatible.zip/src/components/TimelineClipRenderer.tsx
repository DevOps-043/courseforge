import React from 'react';
import {AbsoluteFill, Audio, Img, OffthreadVideo} from 'remotion';
import {assetSrc} from '../lib/assets';
import type {TimelineClip, TimelineTrack, VideoAssemblyManifest} from '../types';

type Props = {clip: TimelineClip; track: TimelineTrack; manifest: VideoAssemblyManifest};

const normalizeObjectFit = (fit: TimelineClip['fit'] | undefined, fallback: TimelineClip['fit'] | undefined): React.CSSProperties['objectFit'] => {
  const value = fit ?? fallback ?? 'cover';
  return value === 'stretch' ? 'fill' : value;
};

export const TimelineClipRenderer: React.FC<Props> = ({clip, track, manifest}) => {
  if (!clip.assetRef) return null;
  const asset = manifest.assets.find((item) => item.id === clip.assetRef);
  if (!asset) return null;
  const src = assetSrc(manifest, asset.id)!;
  const style: React.CSSProperties = {
    position: 'absolute',
    left: clip.box.x,
    top: clip.box.y,
    width: clip.box.width,
    height: clip.box.height,
    objectFit: normalizeObjectFit(clip.fit, asset.metadata?.preferredFit),
    objectPosition: clip.objectPosition ?? 'center center',
    opacity: clip.opacity ?? 1,
    borderRadius: clip.borderRadius ?? 0,
  };
  const startFrom = clip.sourceStartSec === undefined ? undefined : Math.round(clip.sourceStartSec * manifest.project.fps);
  const endAt = clip.sourceEndSec === undefined ? undefined : Math.round(clip.sourceEndSec * manifest.project.fps);

  if (asset.type === 'audio') return <Audio src={src} startFrom={startFrom} endAt={endAt} volume={clip.volume ?? 1} />;
  if (asset.type === 'video') return <OffthreadVideo src={src} startFrom={startFrom} endAt={endAt} muted={clip.muted ?? track.kind !== 'avatar'} volume={clip.volume ?? 1} style={style} />;
  if (asset.type === 'image' || asset.type === 'svg') return <Img src={src} style={style} />;
  if (asset.type === 'html') return <iframe title={clip.id} src={src} style={{...style, border: 0}} />;
  return <AbsoluteFill />;
};
