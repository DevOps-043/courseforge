import React from 'react';
import {AbsoluteFill, Audio, Sequence} from 'remotion';
import {assetSrc} from '../lib/assets';
import {getTimedScenes} from '../lib/timing';
import {SceneRenderer} from '../components/SceneRenderer';
import {TimelineClipRenderer} from '../components/TimelineClipRenderer';
import {resolveRenderManifest, type RenderProps} from '../types';

export const AssembledVideo: React.FC<RenderProps> = (props) => {
  const manifest = resolveRenderManifest(props);
  const timedScenes = getTimedScenes(manifest.scenes ?? [], manifest.project.fps);
  const voice = manifest.audio?.voiceoverRef;
  const music = manifest.audio?.musicRef;
  const timelineTracks = [...(manifest.timeline?.tracks ?? [])].sort((left, right) => left.zIndex - right.zIndex);
  return (
    <AbsoluteFill style={{background: '#090d14', fontFamily: 'Inter, Arial, sans-serif'}}>
      {timelineTracks.length > 0 ? timelineTracks.flatMap((track) => track.clips.map((clip) => {
        const from = Math.round(clip.fromSec * manifest.project.fps);
        const durationInFrames = Math.max(1, Math.round((clip.toSec - clip.fromSec) * manifest.project.fps));
        return <Sequence key={`${track.id}:${clip.id}`} from={from} durationInFrames={durationInFrames} layout="none"><div style={{position: 'absolute', inset: 0, zIndex: track.zIndex}}><TimelineClipRenderer clip={clip} track={track} manifest={manifest} /></div></Sequence>;
      })) : timedScenes.map((scene) => <Sequence key={scene.id} from={scene.from} durationInFrames={scene.durationInFrames}><SceneRenderer scene={scene} manifest={manifest} /></Sequence>)}
      {voice ? <Audio src={assetSrc(manifest, voice)!} /> : null}
      {music ? <Audio src={assetSrc(manifest, music)!} volume={manifest.audio?.musicVolume ?? 0.12} /> : null}
    </AbsoluteFill>
  );
};
