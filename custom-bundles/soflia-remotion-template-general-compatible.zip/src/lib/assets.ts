import {staticFile} from 'remotion';
import type {VideoAssemblyManifest} from '../types';

export const findAsset = (manifest: VideoAssemblyManifest, id: string) => {
  const asset = manifest.assets.find((item) => item.id === id);
  if (!asset) throw new Error(`Asset not found in manifest: ${id}`);
  return asset;
};

const isExternalAsset = (path: string) => /^(?:https?:|data:|blob:)/i.test(path);

export const assetSrc = (manifest: VideoAssemblyManifest, id?: string) => {
  if (!id) return undefined;
  const asset = findAsset(manifest, id);
  return isExternalAsset(asset.path) ? asset.path : staticFile(asset.path);
};
