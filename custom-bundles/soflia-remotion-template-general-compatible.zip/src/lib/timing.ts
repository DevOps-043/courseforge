import type {AssemblyScene, TimedScene, VideoAssemblyManifest} from '../types';

export const secondsToFrames = (seconds: number, fps: number) => Math.max(1, Math.round(seconds * fps));

export const getTimedScenes = (scenes: AssemblyScene[], fps: number): TimedScene[] => {
  let cursor = 0;
  return scenes.map((scene) => {
    const durationInFrames = secondsToFrames(scene.durationSec, fps);
    const timed = {...scene, from: cursor, durationInFrames};
    cursor += durationInFrames;
    return timed;
  });
};

export const getManifestDuration = (manifest: VideoAssemblyManifest) => {
  const fps = manifest.project.fps;
  if (manifest.project.durationSec !== undefined) return secondsToFrames(manifest.project.durationSec, fps);
  if (manifest.timeline) {
    const lastSecond = manifest.timeline.tracks.flatMap((track) => track.clips).reduce((latest, clip) => Math.max(latest, clip.toSec), 0);
    return secondsToFrames(lastSecond, fps);
  }
  return getTimedScenes(manifest.scenes ?? [], fps).reduce((total, scene) => total + scene.durationInFrames, 0);
};
