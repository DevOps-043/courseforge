import type {CSSProperties} from 'react';

export type AssetType = 'image' | 'video' | 'audio' | 'caption' | 'json' | 'svg' | 'font' | 'html';

export type AssemblyAsset = {
  id: string;
  type: AssetType;
  path: string;
  description?: string;
  durationSec?: number;
  role?: 'avatar' | 'slide' | 'broll' | 'voiceover' | 'music' | 'brand' | 'caption' | 'other';
  metadata?: {
    mimeType?: string;
    codec?: string;
    fileSizeBytes?: number;
    checksumSha256?: string;
    width?: number;
    height?: number;
    fps?: number;
    hasAudio?: boolean;
    aspectRatio?: number;
    subjectAnchor?: {x: number; y: number};
    safeArea?: {top?: number; right?: number; bottom?: number; left?: number};
    preferredFit?: 'contain' | 'cover' | 'stretch';
    loop?: boolean;
    alpha?: boolean;
    contentBounds?: {x: number; y: number; width: number; height: number};
    renderer?: 'raster' | 'html' | 'component';
    textEmbedded?: boolean;
    sampleRateHz?: number;
    channels?: number;
    loudnessLufs?: number;
    language?: string;
    speaker?: string;
    bpm?: number;
    captionFormat?: 'srt' | 'vtt' | 'json';
    license?: string;
  };
};

export type SceneType = 'title-card' | 'image-focus' | 'video-clip' | 'quote' | 'stat-highlight' | 'process-step' | 'comparison' | 'screen-demo' | 'recap' | 'cta';

export type MotionSpec = {
  entrance?: 'soft-fade' | 'soft-scale-fade' | 'slide-up' | 'slide-left' | 'mask-reveal';
  transitionOut?: 'crossfade' | 'panel-wipe' | 'none';
  emphasis?: string[];
};

export type SceneLayoutMode = 'full-avatar' | 'centered-slide' | 'split-avatar-slide' | 'slide-broll' | 'centered-brand' | 'custom';

export type VisualSlot = {
  assetRef?: string;
  sourceStartSec?: number;
  sourceEndSec?: number;
  x: number;
  y: number;
  width: number;
  height: number;
  fit?: 'contain' | 'cover' | 'stretch';
  objectPosition?: string;
  opacity?: number;
  borderRadius?: number;
  zIndex?: number;
  safeTextBox?: {x: number; y: number; width: number; height: number};
};

export type SceneLayout = {
  mode: SceneLayoutMode;
  slots?: Record<string, VisualSlot>;
  background?: string;
};

export type LayerSpec = {
  id: string;
  kind: 'avatar' | 'slide' | 'broll' | 'caption' | 'brand' | 'custom';
  assetRef?: string;
  componentId?: string;
  visible?: boolean;
  zIndex: number;
  timeMode?: 'timeline' | 'trim';
  sourceStartSec?: number;
  sourceEndSec?: number;
  box: LayoutBox;
  fit?: 'contain' | 'cover' | 'stretch';
  objectPosition?: string;
  opacity?: number;
  borderRadius?: number;
  safeTextBox?: {x: number; y: number; width: number; height: number};
};

export type TimelineClip = {
  id: string;
  assetRef?: string;
  componentId?: string;
  fromSec: number;
  toSec: number;
  sourceStartSec?: number;
  sourceEndSec?: number;
  box: LayoutBox;
  fit?: 'contain' | 'cover' | 'stretch';
  objectPosition?: string;
  opacity?: number;
  borderRadius?: number;
  muted?: boolean;
  volume?: number;
  loop?: boolean;
  safeTextBox?: {x: number; y: number; width: number; height: number};
};

export type TimelineTrack = {
  id: string;
  kind: 'avatar' | 'slide' | 'broll' | 'caption' | 'audio' | 'brand' | 'custom';
  zIndex: number;
  clips: TimelineClip[];
};

export type AssemblyTimeline = {
  tracks: TimelineTrack[];
};

export type AssemblyScene = {
  id: string;
  type: SceneType;
  durationSec: number;
  title?: string;
  subtitle?: string;
  body?: string;
  label?: string;
  value?: string;
  assetRefs?: string[];
  motion?: MotionSpec;
  background?: string;
  layout?: SceneLayout;
  baseLayerVisible?: boolean;
  layers?: LayerSpec[];
  data?: Record<string, unknown>;
};

export type AudioConfig = {
  voiceoverRef?: string | null;
  musicRef?: string | null;
  musicVolume?: number;
  ducking?: boolean;
};

export type CaptionConfig = {
  enabled?: boolean;
  source?: 'inline-or-srt' | 'asset';
  assetRef?: string;
  style?: 'bottom-safe-area' | 'boxed';
};

export type VideoAssemblyManifest = {
  project: {
    id: string;
    title?: string;
    format: string;
    width: number;
    height: number;
    fps: number;
    language?: string;
    style?: string;
    accentColor?: string;
    durationSec?: number;
  };
  assets: AssemblyAsset[];
  baseLayer?: LayerSpec;
  timeline?: AssemblyTimeline;
  scenes?: AssemblyScene[];
  audio?: AudioConfig;
  captions?: CaptionConfig;
};

export type TimedScene = AssemblyScene & {from: number; durationInFrames: number};

export type LayoutBox = {x: number; y: number; width: number; height: number};

export type LayoutOverrideEdit =
  | {layerId: string; kind: 'position'; x: number; y: number}
  | {layerId: string; kind: 'size'; width: number; height: number}
  | {layerId: string; kind: 'crop'; top: number; right: number; bottom: number; left: number}
  | {layerId: string; kind: 'rotation'; angle: number}
  | {layerId: string; kind: 'stack'; order: number}
  | {layerId: string; kind: 'visibility'; hidden: boolean};

export type LayoutOverrideManifest = {
  version?: number;
  canvas?: {width: number; height: number; fps?: number};
  edits?: LayoutOverrideEdit[];
};

export type LegacyTemplateProps = {
  manifest?: VideoAssemblyManifest;
  accentColor?: string;
  avatarVideoUrl?: string;
  bgMusicUrl?: string;
  bgMusicVolume?: number;
  brollClips?: {durationInFrames?: number; order?: number; url: string}[];
  layoutOverrides?: LayoutOverrideManifest[];
  slides?: {index?: number; url: string}[];
  totalDurationInFrames?: number;
  voiceAudioUrl?: string;
};

export type RenderProps = VideoAssemblyManifest;

export const boxStyle = (box: LayoutBox, overrides: CSSProperties = {}): CSSProperties => ({
  position: 'absolute', left: box.x, top: box.y, width: box.width, height: box.height,
  overflow: 'hidden', ...overrides,
});

const DEFAULT_WIDTH = 1920;
const DEFAULT_HEIGHT = 1080;
const DEFAULT_FPS = 30;
const DEFAULT_ACCENT = '#00D4B3';

const defaultBoxByLayer: Record<string, LayoutBox> = {
  avatar: {x: 0, y: 0, width: 806, height: 1080},
  primaryVisual: {x: 806, y: 0, width: 1114, height: 1080},
  slides: {x: 842, y: 36, width: 1042, height: 643},
  broll: {x: 1364, y: 751, width: 520, height: 293},
};

function isManifest(value: unknown): value is VideoAssemblyManifest {
  const candidate = value as Partial<VideoAssemblyManifest> | undefined;
  return Boolean(candidate?.project && Array.isArray(candidate.assets));
}

function durationFramesToSeconds(frames: number | undefined, fps: number) {
  return Math.max(1, Math.round(frames || fps * 5) / fps);
}

function urlExtension(url: string) {
  const clean = url.split('?')[0]?.split('#')[0] || url;
  return clean.slice(clean.lastIndexOf('.') + 1).toLowerCase();
}

function inferAssetType(url: string, fallback: AssetType): AssetType {
  const extension = urlExtension(url);
  if (['png', 'jpg', 'jpeg', 'webp', 'gif'].includes(extension)) return 'image';
  if (extension === 'svg') return 'svg';
  if (['mp4', 'webm', 'mov'].includes(extension)) return 'video';
  if (['mp3', 'wav', 'm4a', 'aac', 'ogg'].includes(extension)) return 'audio';
  if (['html', 'htm'].includes(extension)) return 'html';
  return fallback;
}

function applyBoxOverrides(layerId: string, fallback: LayoutBox, overrides: LayoutOverrideManifest[] = []) {
  const next = {...fallback};
  for (const manifest of overrides) {
    for (const edit of manifest.edits ?? []) {
      if (edit.layerId !== layerId) continue;
      if (edit.kind === 'position') {
        next.x = edit.x;
        next.y = edit.y;
      }
      if (edit.kind === 'size') {
        next.width = edit.width;
        next.height = edit.height;
      }
    }
  }
  return next;
}

function isHidden(layerId: string, overrides: LayoutOverrideManifest[] = []) {
  return overrides.some((manifest) =>
    (manifest.edits ?? []).some((edit) => edit.layerId === layerId && edit.kind === 'visibility' && edit.hidden),
  );
}

function latestStackOrder(layerId: string, fallback: number, overrides: LayoutOverrideManifest[] = []) {
  let order = fallback;
  for (const manifest of overrides) {
    for (const edit of manifest.edits ?? []) {
      if (edit.layerId === layerId && edit.kind === 'stack') order = edit.order;
    }
  }
  return order;
}

function buildTimelineFromLegacyProps(input: LegacyTemplateProps): VideoAssemblyManifest {
  const fps = 30;
  const totalSeconds = durationFramesToSeconds(input.totalDurationInFrames, fps);
  const accentColor = input.accentColor || DEFAULT_ACCENT;
  const layoutOverrides = Array.isArray(input.layoutOverrides) ? input.layoutOverrides : [];
  const assets: AssemblyAsset[] = [];
  const tracks: TimelineTrack[] = [];
  const addTrack = (track: TimelineTrack) => {
    if (track.clips.length > 0) tracks.push(track);
  };

  if (input.avatarVideoUrl) {
    assets.push({id: 'avatar', type: 'video', path: input.avatarVideoUrl, role: 'avatar'});
    if (!isHidden('avatar', layoutOverrides)) {
      addTrack({
        id: 'avatar',
        kind: 'avatar',
        zIndex: latestStackOrder('avatar', 10, layoutOverrides),
        clips: [{
          id: 'avatar-main',
          assetRef: 'avatar',
          fromSec: 0,
          toSec: totalSeconds,
          box: applyBoxOverrides('avatar', defaultBoxByLayer.avatar, layoutOverrides),
          fit: 'cover',
          muted: false,
        }],
      });
    }
  }

  const slideBox = applyBoxOverrides('slides', defaultBoxByLayer.slides, layoutOverrides);
  const slides = Array.isArray(input.slides) ? input.slides : [];
  if (!isHidden('slides', layoutOverrides) && slides.length > 0) {
    const slideDuration = totalSeconds / slides.length;
    assets.push(...slides.map((slide, index) => ({
      id: `slide-${slide.index ?? index}`,
      type: inferAssetType(slide.url, 'image'),
      path: slide.url,
      role: 'slide' as const,
    })));
    addTrack({
      id: 'slides',
      kind: 'slide',
      zIndex: latestStackOrder('slides', 20, layoutOverrides),
      clips: slides.map((slide, index) => ({
        id: `slide-${slide.index ?? index}`,
        assetRef: `slide-${slide.index ?? index}`,
        fromSec: index * slideDuration,
        toSec: index === slides.length - 1 ? totalSeconds : (index + 1) * slideDuration,
        box: slideBox,
        fit: 'contain',
        borderRadius: 22,
      })),
    });
  }

  const brollBox = applyBoxOverrides('broll', defaultBoxByLayer.broll, layoutOverrides);
  const brollClips = Array.isArray(input.brollClips) ? input.brollClips : [];
  if (!isHidden('broll', layoutOverrides) && brollClips.length > 0) {
    let cursor = 0;
    assets.push(...brollClips.map((clip, index) => ({
      id: `broll-${clip.order ?? index + 1}`,
      type: 'video' as const,
      path: clip.url,
      role: 'broll' as const,
    })));
    addTrack({
      id: 'broll',
      kind: 'broll',
      zIndex: latestStackOrder('broll', 30, layoutOverrides),
      clips: brollClips.map((clip, index) => {
        const duration = durationFramesToSeconds(clip.durationInFrames, fps);
        const fromSec = Math.min(cursor, Math.max(0, totalSeconds - 0.1));
        const toSec = Math.min(totalSeconds, fromSec + duration);
        cursor = toSec;
        return {
          id: `broll-${clip.order ?? index + 1}`,
          assetRef: `broll-${clip.order ?? index + 1}`,
          fromSec,
          toSec: Math.max(fromSec + 0.1, toSec),
          box: brollBox,
          fit: 'cover' as const,
          muted: true,
          borderRadius: 18,
        };
      }),
    });
  }

  const audio: AudioConfig = {musicVolume: input.bgMusicVolume ?? 0.12};
  if (input.voiceAudioUrl) {
    assets.push({id: 'voiceover', type: 'audio', path: input.voiceAudioUrl, role: 'voiceover'});
    audio.voiceoverRef = 'voiceover';
  }
  if (input.bgMusicUrl) {
    assets.push({id: 'music', type: 'audio', path: input.bgMusicUrl, role: 'music'});
    audio.musicRef = 'music';
  }

  return {
    project: {
      id: 'courseforge-template-base',
      title: 'Video ensamblado',
      format: '16:9',
      width: DEFAULT_WIDTH,
      height: DEFAULT_HEIGHT,
      fps: DEFAULT_FPS,
      language: 'es-MX',
      style: 'corporate-explainer',
      accentColor,
      durationSec: totalSeconds,
    },
    assets,
    timeline: {tracks},
    scenes: tracks.length > 0 ? [] : [{
      id: 'fallback',
      type: 'title-card',
      durationSec: totalSeconds,
      label: 'SofLIA Engine',
      title: 'Video en preparacion',
      subtitle: 'Agrega avatar, slides o B-roll para ensamblar la leccion.',
    }],
    audio,
  };
}

export function resolveRenderManifest(rawProps: RenderProps | LegacyTemplateProps): VideoAssemblyManifest {
  if (isManifest(rawProps)) return rawProps;
  if (isManifest((rawProps as LegacyTemplateProps).manifest)) {
    const manifest = (rawProps as LegacyTemplateProps).manifest as VideoAssemblyManifest;
    return {
      ...manifest,
      project: {
        ...manifest.project,
        accentColor: (rawProps as LegacyTemplateProps).accentColor || manifest.project.accentColor,
      },
      audio: {
        ...manifest.audio,
        musicVolume: (rawProps as LegacyTemplateProps).bgMusicVolume ?? manifest.audio?.musicVolume,
      },
    };
  }
  return buildTimelineFromLegacyProps(rawProps as LegacyTemplateProps);
}
