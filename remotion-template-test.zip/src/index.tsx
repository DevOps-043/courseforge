import React from "react";

export const MyComposition = () => {
  return (
    <div style={{ 
      flex: 1, 
      backgroundColor: "#151A21", 
      color: "#00D4B3", 
      display: "flex", 
      justifyContent: "center", 
      alignItems: "center", 
      fontSize: "48px",
      fontWeight: "bold",
      fontFamily: "system-ui"
    }}>
      ¡Sandbox Remotion Activo!
    </div>
  );
};
